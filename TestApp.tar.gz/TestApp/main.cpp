#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlComponent>
#include "rotater.h"

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;

    QQmlComponent component(&engine, QUrl(QStringLiteral("qrc:/main.qml")));
    QObject *object = component.create();
    Rotater rotater(object);

    return app.exec();
}
