#include "rotater.h"
#include <QObject>
#include <QDebug>
#include <QTimer>

Rotater::Rotater(QObject* object)
{
    timer = new QTimer();
    timer->setInterval(1);
    timer->start();
    connect(timer, SIGNAL(timeout()), this, SLOT(rotate()));
    rotationObj = object->findChild<QObject*>("myRotate");
}

void Rotater::rotate()
{
    static int rpm = 0;
    rpm+=100;
    setRpm(rpm);
    timer->start();
}

void Rotater::setRpm(QVariant rpm)
{
    //qDebug()<<Q_FUNC_INFO<<rpm;
    float angle = rpm.toFloat() * (180.0/8000.0);
    if(rotationObj) {
        rotationObj->setProperty("angle", QVariant(angle));
    } else {
        qDebug()<<"Not found";
    }
}
