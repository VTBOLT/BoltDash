#ifndef ROTATER_H
#define ROTATER_H

#include <QVariant>
#include <QObject>
class QTimer;
class Rotater : public QObject
{
    Q_OBJECT
public:
    Rotater(QObject* object);
    void setRpm(QVariant rpm);

private slots:
    void rotate();

private:
    QTimer *timer;
    QObject *rotationObj;
};

#endif // ROTATER_H
